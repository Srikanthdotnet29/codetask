﻿using System;

namespace CroweHorwath.CHDataAccess
{
    /// <summary>
    /// Represents to Message Manager
    /// </summary>
    public  class MessageManager
    {
        /// <summary>
        /// Write all message from this method
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public bool  CreateMessage(string message)
        {
            try
            {
                FactoryData data = new FactoryData();
                IDataAccess access = data.FactoryMethod();

                access.WriteMessage(message);

                return true;
            }
            catch (Exception)
            {

                throw;
            }
            
        }
    }
}
