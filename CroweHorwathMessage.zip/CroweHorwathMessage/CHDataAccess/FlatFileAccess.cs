﻿namespace CroweHorwath.CHDataAccess
{
    /// <summary>
    /// Represents to write a message into Flat file
    /// </summary>
    public class FlatFileAccess : IDataAccess
    {
        /// <summary>
        /// Represents message to a file
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public bool WriteMessage(string message)
        {
            // TODO: Need to implement write message into file
            return true;
        }
    }
}
