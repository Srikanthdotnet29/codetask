﻿
namespace CroweHorwath.CHDataAccess
{
    /// <summary>
    /// Represents to write a message Abstact
    /// </summary>
    public interface IDataAccess
    {
        bool WriteMessage(string message);
    }
}
