﻿
using log4net;

namespace CroweHorwath.CHDataAccess
{
    /// <summary>
    /// Represents message access
    /// </summary>
    public sealed class MessageAccess
    {
        /// <summary>
        /// Hold logger 
        /// </summary>
        ILog log = null;
        public MessageAccess()
        {
            log = LogManager.GetLogger(GetType());
        }
        /// <summary>
        /// Represents to get welcome message
        /// </summary>
        /// <param name="name">Holds a name</param>
        /// <returns>Returns message with name</returns>
        public string GetWelcomeMessage()
        {
            log.Debug("Enter GetWelcomeMessage");
            try
            {
                return "Hello World";
            }
            catch (System.Exception ex)
            {
                log.Error("ERROR in GetWelcomeMessage", ex);
                return "-1";
            }
            finally
            {
                log.Debug("Exit GetWelcomeMessage");
            }
        }
    }
}
