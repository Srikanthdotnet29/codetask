﻿using System;

namespace CroweHorwath.CHDataAccess
{
    /// <summary>
    /// Represents to factory of Write message 
    /// </summary>
    public class FactoryData
    {
        /// <summary>
        /// Represets to get data access based on configuration value
        /// </summary>
        /// <returns></returns>
        public IDataAccess FactoryMethod()
        {
            IDataAccess access = null;
            try
            {
                string storeType = System.Configuration.
                    ConfigurationManager.AppSettings["StoreType"];
                switch (storeType)
                {
                    case "Database":
                        access = new SqlDataAccess();
                        break;
                    case "FlatFile":
                        access = new FlatFileAccess();
                        break;

                    default:
                        access = new SqlDataAccess();
                        break;
                }

            }
            catch (Exception)
            {
                access = null;
                throw;
            }

            return access;
        }
    }
}
