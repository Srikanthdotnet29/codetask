﻿namespace CroweHorwath.CHDataAccess
{
    /// <summary>
    /// Represents to write a message into SQL database
    /// </summary>
    public class SqlDataAccess : IDataAccess
    {
        public bool WriteMessage(string message)
        {
            // TODO: Need to implement write message into file
            return true;
        }
    }
}
