﻿using CroweHorwath.CHServices;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text.RegularExpressions;

namespace CroweHorwathServices.Test
{
    [TestClass]
    public class TestMessageController
    {
        /// <summary>
        /// Represents to validate getmessage having message
        /// </summary>
        [TestMethod]
        public void GetMessage_IsNotNull()
        {
            var controller = new MessageController();
            var result = controller.GetMessage();
            Assert.IsNotNull(result);
        }
        /// <summary>
        /// Represents to validate get message with only alphanumeric 
        /// and digits and min length 2 and max length 50
        /// </summary>
        [TestMethod]
        public void GetMessage_ValidateMessage()
        {
            var controller = new MessageController();
            var result = controller.GetMessage();
            StringAssert.Matches(result, new Regex("^[a-zA-Z0-9 ]{2,50}$"));
        }
        /// <summary>
        /// Represents to validate get message result match with excepted result
        /// </summary>
        [TestMethod]
        public void GetMessage_Match()
        {
            var controller = new MessageController();
            var result = controller.GetMessage();
            if (string.IsNullOrWhiteSpace(result))
                Assert.Fail();

            StringAssert.Equals(result.ToUpper(), "Hello World".ToUpper());
        }
    }
}
