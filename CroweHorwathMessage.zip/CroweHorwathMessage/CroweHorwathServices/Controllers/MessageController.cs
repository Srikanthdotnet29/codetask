﻿using CroweHorwath.CHDataAccess;
using System;
using System.Web.Http;

namespace CroweHorwath.CHServices
{
    /// <summary>
    /// Represents to Message Controller
    /// </summary>
    public class MessageController : ApiController
    {
        /// <summary>
        /// Represents to get message
        /// </summary>
        /// <returns></returns>
        public string GetMessage()
        {
            try
            {
                MessageAccess access = new MessageAccess();
                return access.GetWelcomeMessage();
            }
            catch (Exception)
            {
                return "-1";
            }
        }
        /// <summary>
        /// Represents to write a message to config store
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public bool WriteMessage(string message)
        {
            try
            {
                MessageManager access = new MessageManager();
                return access.CreateMessage(message);
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}