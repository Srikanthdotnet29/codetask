﻿using System;
using System.Web.Script.Serialization;

namespace CroweHorwath.ConsoleDisplay
{
    class Program
    {
        /// <summary>
        /// Hello World message display console app.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            try
            {
                using (var client = new System.Net.WebClient())
                {
                    client.Headers.Add("Content-Type:application/text");
                    client.Headers.Add("Accept:application/text");

                    // TODO: need to chage localhost:52832 to after 
                    // running CroweHorwathServices that port or iis hosting url.

                    var result = client.DownloadString
                        ("http://localhost:52832/api/message/GetMessage");

                    Console.WriteLine(Environment.NewLine +
                        new JavaScriptSerializer().Deserialize<string>(result));

                    Console.ReadLine();
                }
            }
            catch (Exception)
            {
                throw;
            }

        }
    }
}
